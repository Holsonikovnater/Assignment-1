//Holsonikov Dorisca , 40316045
//William Huynh , 40319618
#include "Room.hpp"

#include <iostream> 

int main ()
{

    Room room1; 
    room1.setId(12345); 
    room1.setCapacity(250); 
    room1.printRoom(); 
    return 0 ; 
}