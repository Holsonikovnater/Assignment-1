//Holsonikov Dorisca , 40316045
//William Huynh , 40319618
// Name : Holsonikov Dorisca Student Id: 40316045

#include <iostream> 
#include "Student.h"

int main ()
{
    Student student1; 
    student1.setStudentID("12345678"); 
    student1.setFirstName("Daniel"); 
    student1.setLastName("Cossette");
    student1.setAdress("123 road");
    student1.setEmail("heuiibbeubce@gmail.com"); 
    student1.studentPrint(); 

    return 0; 
}